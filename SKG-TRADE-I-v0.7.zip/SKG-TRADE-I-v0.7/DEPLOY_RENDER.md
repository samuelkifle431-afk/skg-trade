# SKG TRADE I v0.7 — Render deployment

This release is packaged as a **single-origin deployment candidate**: FastAPI serves both the API and the browser frontend. This avoids manual CORS setup and avoids a separate frontend host.

## Before you start

- A GitHub account and a new private or public repository for this project.
- A Render account.
- Provider credentials are optional for the first deployment. Without them, Twelve Data feeds and AI screenshot analysis will report that they are not configured.
- Render hosting and managed PostgreSQL may incur charges. Review the current plan and database pricing before confirming deployment.

## Deploy from Android or desktop

1. Download and extract `SKG-TRADE-I-v0.7.zip`.
2. Create a GitHub repository named `skg-trade-i`.
3. Upload the **contents** of the extracted `SKG-TRADE-I-v0.7` folder to the repository root. Confirm that `render.yaml` is at the repository root and `backend/` is beside it.
4. In Render, choose **New → Blueprint** and connect the GitHub repository.
5. Review the resources Render proposes: one Python web service and one PostgreSQL database. Review their prices/plan limits before applying.
6. Apply the Blueprint. Render generates `JWT_SECRET` and wires the database connection.
7. When the service deploys, open its `onrender.com` URL. `/health` should return a JSON health response; `/docs` opens API documentation; `/` opens the SKG TRADE I web app.
8. Register a test account. Confirm login and the private journal before sharing the URL.

## Optional API keys

After deployment, open the Render web service → Environment and add:

- `TWELVEDATA_API_KEY` — for supported non-Binance instruments. Availability depends on provider symbol coverage and plan.
- `OPENAI_API_KEY` — for chart screenshot analysis.
- `OPENAI_VISION_MODEL` — optional; default is `gpt-4o-mini`.

Save changes and redeploy. Never put these keys in `index.html`, `app.js`, `integration.js`, GitHub, or a screenshot.

## Important checks before public launch

- Confirm HTTPS is active and `/health` returns `status: ok`.
- Test registration, login, logout, and journal isolation with two separate accounts.
- Test image upload rejection for invalid file types and files larger than 8 MB.
- Test provider-unavailable behavior; the app must not invent market prices.
- Configure database backups and verify a restore.
- Add email verification, password reset, rate limiting/bot protection, privacy policy, terms, support contact, and operational monitoring before inviting the public.
- Review the provider's data licensing, quotas, and costs.

## Scope and limitations

This is a deployment-configured candidate, **not a live deployment**. The repository must be uploaded and the Blueprint applied by the account owner. I cannot create or access your GitHub/Render accounts from this ZIP. Provider API calls have not been verified using your credentials. The strategy output is educational analysis, not financial advice or a probability of profit. No order execution route exists.
