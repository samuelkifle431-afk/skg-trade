# SKG TRADE I v0.7

A mobile-friendly, analysis-only trading web app packaged for a single-origin Render deployment.

## Features
- English / Amharic browser interface
- Public registration and JWT login
- Per-user private trading journal
- Rule-based OHLC analysis (EMA20/50, RSI14, ATR14)
- Binance public spot candles for supported crypto pairs
- Twelve Data adapter for supported forex, metals, crypto, indices, and equities (API key required)
- Optional AI chart-image analysis (OpenAI-compatible vision API key required)
- Analysis-only mode; no order execution
- FastAPI serves the frontend and API on one HTTPS origin
- Render Blueprint for a Python web service and PostgreSQL database

## Deploy
Follow [`DEPLOY_RENDER.md`](DEPLOY_RENDER.md). The user must upload the project to GitHub and apply the Blueprint in their own Render account. The ZIP itself is not a hosted website.

## Local run
```bash
cd backend
python -m venv .venv
# activate the virtual environment, then:
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Open `http://127.0.0.1:8000`. Set `OPENAI_API_KEY` and `TWELVEDATA_API_KEY` in backend environment variables to enable those integrations. Use a unique `JWT_SECRET` outside local development.

## Security and launch caveats
Before opening to the public, add email verification, password reset, rate limiting/bot protection, backups, monitoring, legal pages, and a security review. Confirm provider permissions, market-data licensing, and costs. The included admin overview is an API endpoint, not a full admin UI. Screenshot analysis can misread chart labels. Confidence/evidence scores are not win probabilities. Never treat generated levels as guaranteed trade instructions.
