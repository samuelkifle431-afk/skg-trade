# SKG TRADE I v0.4 — Market data setup

## What is included

- Provider adapter interface with an automatic selection mode.
- Binance public spot OHLC candles for crypto symbols such as `BTCUSDT`.
- Twelve Data adapter for forex, gold, crypto, indices and stocks where the chosen plan supports the requested instrument and interval.
- Authenticated endpoint: `GET /api/market/candles?market=crypto&symbol=BTCUSDT&timeframe=5M&limit=200`
- Provider status endpoint: `GET /api/market/providers`
- No synthetic/demo candles are returned as if they were live. If a provider is unavailable or not configured, the API returns an explicit error.

## Configure

1. Copy `backend/.env.example` to `backend/.env`.
2. Set `MARKET_DATA_PROVIDER=auto`, `binance`, or `twelvedata`.
3. Add `TWELVEDATA_API_KEY` for Twelve Data requests.
4. Start the backend using the existing Docker Compose instructions in `README.md`.
5. Register/login, copy the bearer token, and call the authenticated market endpoint.

## Important provider limitations

- Binance adapter is for spot crypto only; it is not a forex, CFD, futures or stock feed.
- Twelve Data symbol availability, real-time versus delayed quotes, request limits, and asset coverage depend on the account plan and exchange permissions. Confirm coverage for each symbol before production use.
- `gold` symbols may be provider-specific (for example, `XAU/USD` if supported by the account).
- Market data is for analysis and may be delayed, incomplete, or unavailable. Always display provider and timestamp to users and verify quotes against their broker before making a trading decision.
- This release does not place orders and does not claim to provide guaranteed signals.
